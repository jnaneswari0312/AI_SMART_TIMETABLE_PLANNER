import streamlit as st
import pandas as pd
import random
from datetime import datetime, timedelta
from io import BytesIO

st.set_page_config(page_title="AI Smart Timetable", page_icon="📅", layout="wide")
st.title("📅 AI Smart Timetable Generator")
st.write("Create a balanced weekly timetable and download it as CSV or Excel.")

with st.sidebar:
    st.header("Timetable settings")
    days = st.multiselect("Working days",
        ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        default=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"])
    periods = st.number_input("Periods per day", 1, 10, 6)
    duration = st.selectbox("Period duration (minutes)", [40, 45, 50, 55, 60], index=1)
    start = st.time_input("College start time", value=datetime.strptime("09:00", "%H:%M").time())
    break_after = st.number_input("Break after period (0 = no break)", 0, int(periods), 3)
    break_minutes = st.number_input("Break duration (minutes)", 5, 60, 15)

st.subheader("1. Subjects and weekly periods")
default = pd.DataFrame({
    "Subject": ["Mathematics", "DBMS", "Operating Systems", "Python", "Artificial Intelligence"],
    "Periods per week": [4, 4, 3, 3, 2],
    "Teacher": ["Teacher 1", "Teacher 2", "Teacher 3", "Teacher 4", "Teacher 5"]
})
subjects = st.data_editor(default, num_rows="dynamic", use_container_width=True)
seed = st.number_input("Arrangement seed (change to generate another arrangement)", min_value=0, value=42)

def build_slots(count, start_time, minutes, break_period, break_len):
    current = datetime.combine(datetime.today(), start_time)
    result = []
    for p in range(1, count + 1):
        end = current + timedelta(minutes=minutes)
        result.append((p, current.strftime("%I:%M %p"), end.strftime("%I:%M %p")))
        current = end
        if break_period and p == break_period:
            current += timedelta(minutes=break_len)
    return result

def generate(rows):
    if not days:
        raise ValueError("Select at least one working day.")
    slots_count = len(days) * int(periods)
    total = sum(int(r["Periods per week"]) for r in rows)
    if total > slots_count:
        raise ValueError(f"Subjects need {total} periods, but only {slots_count} slots are available.")
    rng = random.Random(int(seed))
    lessons = []
    for r in rows:
        lessons.extend([{"Subject": r["Subject"], "Teacher": r["Teacher"]}] * int(r["Periods per week"]))
    best_df, best_score = None, 10**9
    for _ in range(100):
        pool = lessons[:]
        rng.shuffle(pool)
        grid = {d: [None] * int(periods) for d in days}
        daily_count = {d: {} for d in days}
        for d in days:
            for i in range(int(periods)):
                if not pool:
                    break
                choices = []
                for j, item in enumerate(pool):
                    score = rng.random() + daily_count[d].get(item["Subject"], 0) * 4
                    if i and grid[d][i-1] and grid[d][i-1]["Subject"] == item["Subject"]:
                        score += 100
                    choices.append((score, j))
                _, j = min(choices)
                item = pool.pop(j)
                grid[d][i] = item
                daily_count[d][item["Subject"]] = daily_count[d].get(item["Subject"], 0) + 1
        score = sum(10 for d in days for i in range(1, int(periods))
                    if grid[d][i] and grid[d][i-1] and grid[d][i]["Subject"] == grid[d][i-1]["Subject"])
        if score < best_score:
            best_score = score
            output = []
            day_slots = build_slots(int(periods), start, duration, int(break_after), int(break_minutes))
            for d in days:
                for i, (p, begin, end) in enumerate(day_slots):
                    item = grid[d][i]
                    output.append({"Day": d, "Period": p, "Time": f"{begin} - {end}",
                                   "Subject": item["Subject"] if item else "Free Period",
                                   "Teacher": item["Teacher"] if item else ""})
            best_df = pd.DataFrame(output)
    return best_df

if st.button("✨ Generate smart timetable", type="primary", use_container_width=True):
    clean = subjects.copy()
    clean["Subject"] = clean["Subject"].fillna("").astype(str).str.strip()
    clean["Teacher"] = clean["Teacher"].fillna("").astype(str).str.strip()
    clean = clean[(clean["Subject"] != "") & clean["Periods per week"].notna()]
    rows = [{"Subject": r["Subject"], "Teacher": r["Teacher"],
             "Periods per week": int(r["Periods per week"])} for _, r in clean.iterrows()]
    try:
        if not rows:
            raise ValueError("Enter at least one subject.")
        st.session_state["timetable"] = generate(rows)
    except ValueError as e:
        st.error(str(e))

if "timetable" in st.session_state:
    df = st.session_state["timetable"]
    st.subheader("2. Your weekly timetable")
    view = df.pivot(index=["Period", "Time"], columns="Day", values="Subject").reset_index()
    st.dataframe(view, use_container_width=True, hide_index=True)
    st.caption("This app uses a rule-based scheduling heuristic (not a trained machine-learning model). Verify teacher availability and college rules.")
    st.download_button("⬇️ Download CSV", df.to_csv(index=False).encode("utf-8"),
                       "ai_smart_timetable.csv", "text/csv")
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        view.to_excel(writer, index=False, sheet_name="Weekly Timetable")
        df.to_excel(writer, index=False, sheet_name="Period Details")
    st.download_button("⬇️ Download Excel", buffer.getvalue(), "ai_smart_timetable.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
else:
    st.info("Edit the subject list and settings, then generate your timetable.")
